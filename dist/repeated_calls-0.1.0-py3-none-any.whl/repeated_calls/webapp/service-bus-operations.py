"""
Service Bus Operations Module

This module provides functionality to interact with Azure Service Bus for sending and receiving messages.
It combines functionalities from the create_scenario.py and receive_messages.py files.
"""
import json
import asyncio
import os
from azure.servicebus.aio import ServiceBusClient
from azure.servicebus import ServiceBusMessage
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# Load environment variables
load_dotenv(dotenv_path='connection-string-servicebus.env')
CONNECTION_STR = 'Endpoint=sb://servicebus-3sqycs22xsz7w.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=tntHhRh3O4KPu5DX+s8MheqcnXiR/onGG+ASbMELNm8='

# Queue names
QUEUE_INPUT = 'customercalls'
QUEUE_RESULTS = 'callresults'

class ServiceBusOperations:
    """Class that handles Azure Service Bus operations."""
    
    @staticmethod
    async def send_message(message_content, queue_name=QUEUE_INPUT):
        """
        Send a message to Azure Service Bus queue.
        
        Args:
            message_content (str or dict): Content to send to Service Bus. 
                                          If dict, it will be converted to JSON string.
            queue_name (str): Name of the queue to send the message to.
                             Defaults to input queue.
        
        Returns:
            bool: True if message was sent successfully, False otherwise.
        """
        if not CONNECTION_STR:
            logger.error("Service Bus connection string not found in environment variables")
            return False
            
        # Convert dict to JSON string if needed
        if isinstance(message_content, dict):
            message_content = json.dumps(message_content)
            
        try:
            # Create a Service Bus client
            async with ServiceBusClient.from_connection_string(
                conn_str=CONNECTION_STR,
                logging_enable=True
            ) as servicebus_client:
                # Create a sender for the queue
                sender = servicebus_client.get_queue_sender(queue_name=queue_name)
                
                async with sender:
                    # Create and send the message
                    message = ServiceBusMessage(message_content)
                    await sender.send_messages(message)
                    logger.info(f"Message sent to queue: {queue_name}")
                    return True
                    
        except Exception as e:
            logger.error(f"Error sending message to Service Bus queue {queue_name}: {str(e)}")
            return False
    
    @staticmethod
    async def receive_messages(queue_name=QUEUE_INPUT, max_messages=100, wait_time=5):
        """
        Receive messages from Azure Service Bus queue.
        
        Args:
            queue_name (str): Name of the queue to receive messages from.
                             Defaults to input queue.
            max_messages (int): Maximum number of messages to receive.
            wait_time (int): Maximum time to wait for messages in seconds.
            
        Returns:
            list: List of received messages or empty list if none received.
        """
        if not CONNECTION_STR:
            logger.error("Service Bus connection string not found in environment variables")
            return []
            
        received_msgs = []
        
        try:
            # Create a Service Bus client
            async with ServiceBusClient.from_connection_string(
                conn_str=CONNECTION_STR,
                logging_enable=True
            ) as servicebus_client:
                # Create a receiver for the queue
                receiver = servicebus_client.get_queue_receiver(queue_name=queue_name)
                
                async with receiver:
                    # Receive messages from the queue with retry logic
                    retry_count = 0
                    max_retries = 3
                    
                    while retry_count < max_retries:
                        try:
                            messages = await receiver.receive_messages(
                                max_wait_time=wait_time,
                                max_message_count=max_messages
                            )
                            
                            # Process received messages
                            if messages:
                                for msg in messages:
                                    logger.info(f"Received message from {queue_name}: {str(msg)}")
                                    received_msgs.append(str(msg))
                                    # Complete the message (remove from queue)
                                    await receiver.complete_message(msg)
                                
                                # Break the retry loop if messages were processed successfully
                                break
                            else:
                                logger.info(f"No messages in queue: {queue_name}")
                                break
                                
                        except Exception as e:
                            logger.warning(f"Error receiving messages from {queue_name}, retry {retry_count + 1}: {str(e)}")
                            retry_count += 1
                            # Implement exponential backoff
                            await asyncio.sleep(2 ** retry_count)
                    
        except Exception as e:
            logger.error(f"Error connecting to Service Bus queue {queue_name}: {str(e)}")
        
        return received_msgs

    @staticmethod
    async def send_result(result_data):
        """
        Send a result message to the results queue.
        
        Args:
            result_data (dict): Result data to send.
        
        Returns:
            bool: True if message was sent successfully, False otherwise.
        """
        return await ServiceBusOperations.send_message(result_data, QUEUE_RESULTS)
    
    @staticmethod
    async def receive_results(max_messages=100, wait_time=5):
        """
        Receive result messages from the results queue.
        
        Args:
            max_messages (int): Maximum number of messages to receive.
            wait_time (int): Maximum time to wait for messages in seconds.
            
        Returns:
            list: List of received messages or empty list if none received.
        """
        return await ServiceBusOperations.receive_messages(QUEUE_RESULTS, max_messages, wait_time)


# Example usage
async def send_example():
    """Example function showing how to send a message."""
    message = {
        "customer_id": "12345",
        "call_reason": "Product inquiry"
    }
    success = await ServiceBusOperations.send_message(message)
    print(f"Message sent successfully: {success}")


async def receive_example():
    """Example function showing how to receive messages."""
    messages = await ServiceBusOperations.receive_messages()
    if messages:
        print(f"Received {len(messages)} messages:")
        for msg in messages:
            print(f"---NEW INCOMING CALL---\n{msg}")
    else:
        print("No messages received")


# Main function to run examples
async def main():
    """Main function to demonstrate sending and receiving messages."""
    # Uncomment the function you want to run
    # await send_example()
    # await receive_example()
    pass


# Entry point for script execution
if __name__ == "__main__":
    asyncio.run(main())
