"""Utilty module for connecting to Azure Service Bus and sending messages."""
