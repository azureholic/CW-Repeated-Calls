"""This module contains the initialization code for the entities package."""

# Ensure directories are treated as packages
