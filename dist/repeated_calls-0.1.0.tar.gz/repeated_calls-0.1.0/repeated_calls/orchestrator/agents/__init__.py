"""Library of prebuilt Semantic Kernel agents."""
