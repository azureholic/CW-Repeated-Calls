"""
Combined Service Bus Demo Application

This application demonstrates how to use the ServiceBusOperations class
to send and receive messages from Azure Service Bus within a Streamlit app.
It also directly calls the orchestrator for processing call events.
"""
import streamlit as st
import asyncio
import json
import os
import polars as pl
from service_bus_operations import ServiceBusOperations
from orchestrator_bridge import process_call_event, process_next_queue_message, get_event_from_service_bus

# Page configuration
st.set_page_config(page_title="Customer Calls Service Bus Demo", page_icon='📞', layout="wide")
st.title("Azure Service Bus Demo")

# Tabs for send and receive operations
tab1, tab2, tab3 = st.tabs(["Create Scenario & Process", "Service Bus Messages", "View Results"])

# Load scenario data
try:
    with open('../data/scenarios/scenario_specifications.json', 'r') as file:
        pay_load = json.load(file)
    scenarios_loaded = True
except Exception as e:
    st.error(f"Error loading scenario data: {str(e)}")
    scenarios_loaded = False

# Create and process scenario tab
with tab1:
    st.header("Create Scenario & Process")
    
    if not scenarios_loaded:
        st.warning("Scenario data could not be loaded. Please check the file path.")
    else:
        # Selectbox with different scenarios
        option = st.selectbox(
            f"***Pick a scenario:***",
            ([f'Scenario {i+1}' for i in range(len(pay_load))])
        )
        
        # Description of the selected scenarios + dropdown menu's
        for i in range(len(pay_load)):
            if option == f'Scenario {i+1}':
                # Header
                col_a, col_b, col_c = st.columns([8,1,1])
                col_a.write(f"***Description of the scenario:*** \
                       \n {pay_load[i]['title']}")
                
                # Option to send to Service Bus only
                if col_b.button("Queue Only"):
                    # Create message content
                    message_content = {
                        "customer_id": pay_load[i]['customer']['customer_id'],
                        "call_reason": pay_load[i]['scenario_details']['call_reason'],
                        "scenario": i + 1
                    }
                    
                    # Send the message to Service Bus
                    if asyncio.run(ServiceBusOperations.send_message(message_content)):
                        st.success(f"Message sent to Service Bus! Scenario {i+1} queued.")
                    else:
                        st.error("Failed to send message to Service Bus. Check logs for details.")
                
                # Option for direct processing
                if col_c.button("Process Now"):
                    # Create message content
                    message_content = {
                        "customer_id": pay_load[i]['customer']['customer_id'],
                        "call_reason": pay_load[i]['scenario_details']['call_reason'],
                        "scenario": i + 1
                    }
                    
                    # Process directly and display results
                    with st.spinner("Processing scenario..."):
                        result = asyncio.run(process_call_event(message_content))
                        
                    if result.get("success", False):
                        st.success("Processing complete!")
                        
                        # Display the result in an expander
                        with st.expander("Processing Result", expanded=True):
                            # Create two columns for structured view
                            col1, col2 = st.columns([1, 3])
                            
                            with col1:
                                st.write("**Customer ID:**")
                                st.write("**Timestamp:**")
                                st.write("**Is Repeated Call:**")
                                if "cause" in result:
                                    st.write("**Cause:**")
                                if "recommendation" in result:
                                    st.write("**Recommendation:**")
                                
                            with col2:
                                st.write(f"{result.get('customer_id', 'N/A')}")
                                st.write(f"{result.get('timestamp', 'N/A')}")
                                st.write(f"{result.get('is_repeated_call', 'N/A')}")
                                if "cause" in result:
                                    st.write(f"{result.get('cause', 'N/A')}")
                                if "recommendation" in result:
                                    st.write(f"{result.get('recommendation', 'N/A')}")
                                
                            # Raw data section
                            with st.expander("Raw Data"):
                                st.code(json.dumps(result, indent=2), language="json")
                    else:
                        st.error(f"Failed to process the scenario: {result.get('error', 'Unknown error')}")

                # Customer PII
                with st.expander(f"**Customer personal information:**"):
                    col1, col2 = st.columns([1,6])
                    
                    col1.write("Customer name:")
                    col2.write(f"{pay_load[i]['customer']['name']}")

                    col1.write("Customer ID:")
                    col2.write(f"{pay_load[i]['customer']['customer_id']}")
                    
                    col1.write("Customer CLV:")
                    col2.write(f"{pay_load[i]['customer']['clv']}")
                
                # Product information
                with st.expander("**Product info of the customer:**"):
                    col1, col2 = st.columns([1,6])
                    
                    col1.write("Product name:")
                    col2.write(f"{pay_load[i]['product']['name']}")

                    col1.write("Product type:")
                    col2.write(f"{pay_load[i]['product']['type']}")

                # Call dates
                with st.expander("**Previous call dates**"):
                    col1, col2 = st.columns([1,6])
                    
                    col1.write("Primary call date:")
                    col2.write(f"{pay_load[i]['dates']['primary_call_date']}")

                    col1.write("Most recent call date:")
                    col2.write(f"{pay_load[i]['dates']['previous_call_dates']}")

                # Scenario details
                with st.expander("**Scenario details**"):
                    col1, col2 = st.columns([1,6])

                    with col1:
                        st.write("Call reason:")
                        st.write("Call history analysis:")
                        st.write("Operational insights:")
                        st.write("Customer insights:")
                        st.write("Recommended system response:")

                    with col2:
                        st.write(f"{pay_load[i]['scenario_details']['call_reason']}")
                        st.write(f"{pay_load[i]['scenario_details']['call_history_analysis']}")
                        st.write(f"{pay_load[i]['scenario_details']['operational_insight']}")
                        st.write(f"{pay_load[i]['scenario_details']['customer_insights_and_retention_strategy']}")
                        
                        for j, response in enumerate(pay_load[i]['scenario_details']['recommended_system_response']):
                            st.write(f'{j+1}: {response}')

# Service Bus Messages tab
with tab2:
    st.header("Service Bus Queue Operations")
    
    col1, col2, col3 = st.columns([1, 1, 1])
    
    # Check for messages button
    if col1.button("Check for Messages"):
        with st.spinner("Checking for input messages..."):
            # Receive messages from Service Bus
            messages = asyncio.run(ServiceBusOperations.receive_messages(wait_time=2))
            
            if messages:
                st.success(f"Found {len(messages)} messages in the queue!")
                for i, msg in enumerate(messages, 1):
                    with st.expander(f"Message {i}"):
                        st.code(msg, language="json")
            else:
                st.info("No input messages in the queue.")
    
    # Process next message button
    if col2.button("Process Next Message"):
        with st.spinner("Processing next message from queue..."):
            # Get and process the next message in the queue
            result = asyncio.run(process_next_queue_message())
            
            if result:
                st.success("Successfully processed message from queue!")
                
                # Display the processing result
                with st.expander("Processing Result", expanded=True):
                    # Create two columns for structured view
                    col1, col2 = st.columns([1, 3])
                    
                    with col1:
                        st.write("**Customer ID:**")
                        st.write("**Timestamp:**")
                        st.write("**Is Repeated Call:**")
                        if "cause" in result:
                            st.write("**Cause:**")
                        if "recommendation" in result:
                            st.write("**Recommendation:**")
                        
                    with col2:
                        st.write(f"{result.get('customer_id', 'N/A')}")
                        st.write(f"{result.get('timestamp', 'N/A')}")
                        st.write(f"{result.get('is_repeated_call', 'N/A')}")
                        if "cause" in result:
                            st.write(f"{result.get('cause', 'N/A')}")
                        if "recommendation" in result:
                            st.write(f"{result.get('recommendation', 'N/A')}")
                        
                    # Raw data section
                    with st.expander("Raw Data"):
                        st.code(json.dumps(result, indent=2), language="json")
            else:
                st.warning("No messages in the queue to process.")
    
    # Send test message button
    if col3.button("Send Test Message"):
        with st.spinner("Sending test message..."):
            test_message = {
                "customer_id": "999",
                "call_reason": "Test message",
                "scenario": 0
            }
            if asyncio.run(ServiceBusOperations.send_message(test_message)):
                st.success("Test message sent to queue!")
            else:
                st.error("Failed to send test message.")

# Results tab
with tab3:
    st.header("View Processing Results")
    
    if st.button("Check for Results"):
        with st.spinner("Checking for result messages..."):
            # Receive result messages from Service Bus
            results = asyncio.run(ServiceBusOperations.receive_results())
            
            if results:
                st.success(f"Received {len(results)} result messages!")
                
                # Display results in a more structured way
                for i, result_msg in enumerate(results, 1):
                    try:
                        # Try to parse the JSON from the message
                        if isinstance(result_msg, str):
                            # Try to extract JSON from a string that might contain metadata
                            import re
                            json_pattern = r'\{.*\}'
                            match = re.search(json_pattern, result_msg)
                            if match:
                                result_data = json.loads(match.group(0))
                            else:
                                try:
                                    result_data = json.loads(result_msg)
                                except json.JSONDecodeError:
                                    result_data = {"raw_message": result_msg}
                        else:
                            result_data = result_msg
                            
                        # Display the result in an expander
                        with st.expander(f"Result {i} - Customer ID: {result_data.get('customer_id', 'Unknown')}"):
                            # Create two columns for structured view
                            col1, col2 = st.columns([1, 3])
                            
                            with col1:
                                st.write("**Customer ID:**")
                                st.write("**Timestamp:**")
                                st.write("**Is Repeated Call:**")
                                if "cause" in result_data:
                                    st.write("**Cause:**")
                                if "recommendation" in result_data:
                                    st.write("**Recommendation:**")
                                
                            with col2:
                                st.write(f"{result_data.get('customer_id', 'N/A')}")
                                st.write(f"{result_data.get('timestamp', 'N/A')}")
                                st.write(f"{result_data.get('is_repeated_call', 'N/A')}")
                                if "cause" in result_data:
                                    st.write(f"{result_data.get('cause', 'N/A')}")
                                if "recommendation" in result_data:
                                    st.write(f"{result_data.get('recommendation', 'N/A')}")
                                
                            # Raw data section
                            with st.expander("Raw Data"):
                                st.code(json.dumps(result_data, indent=2), language="json")
                                
                    except Exception as e:
                        st.error(f"Error parsing result message {i}: {str(e)}")
                        st.code(result_msg)
            else:
                st.info("No result messages in the queue.")

# Documentation
with st.expander("Usage Documentation"):
    st.markdown("""
    ## How to Use This Application
    
    This application demonstrates two ways of working with repeated calls processing:
    
    ### Direct Processing Method
    
    1. **Create Scenario & Process**
       - Select a scenario from the dropdown menu
       - Review the scenario details in the expandable sections
       - Click "Process Now" to immediately process the scenario without using a queue
       - View results instantly on the same screen
    
    ### Queue-Based Method
    
    1. **Create Scenario & Queue**
       - Select a scenario from the dropdown menu
       - Click "Queue Only" to send the message to the Service Bus queue
    
    2. **Service Bus Queue Operations**
       - "Check for Messages" - View messages currently in the input queue
       - "Process Next Message" - Process the next message in the queue directly
       - "Send Test Message" - Add a test message to the queue
    
    3. **View Processing Results**
       - After messages are processed, results are stored in a results queue
       - Click "Check for Results" to view processing outcomes from the results queue
       - Results show whether a call was identified as a repeat call, the cause, and recommendations
    
    ### Complete Flows:
    
    **Direct Processing:**
    1. Select scenario and click "Process Now" in tab 1
    2. View results immediately on the same screen
    
    **Queue-Based Processing:**
    1. Send a scenario message with "Queue Only" from tab 1
    2. Go to tab 2 and click "Process Next Message" to process it
    3. View the results in tab 3 with "Check for Results"
    
    ### Requirements
    - A valid Azure Service Bus connection string in `connection-string-servicebus.env` file
    - Two queues configured in Azure Service Bus: 'customercalls' and 'callresults'
    """)
